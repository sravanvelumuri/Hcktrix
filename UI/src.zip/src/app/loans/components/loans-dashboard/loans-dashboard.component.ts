import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loans-dashboard',
  templateUrl: './loans-dashboard.component.html',
  styleUrls: ['./loans-dashboard.component.scss']
})
export class LoansDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
