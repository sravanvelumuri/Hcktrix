import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loans-registration-form',
  templateUrl: './loans-registration-form.component.html',
  styleUrls: ['./loans-registration-form.component.scss']
})
export class LoansRegistrationFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
