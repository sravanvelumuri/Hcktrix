import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loans-landing',
  templateUrl: './loans-landing.component.html',
  styleUrls: ['./loans-landing.component.scss']
})
export class LoansLandingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
